// alert("This is an alert")
window.addEventListener('load'(event) => {
var x = document.getElementsByclassName(".custom-popup-container");
console.log(x);
x.style.display = "block";
}